'use strict';

const {app, BrowserWindow, Menu} = require('electron');
const windowStateKeeper = require('electron-window-state');

let mainWindow;

function createWindow() {
    let mainWindowState = windowStateKeeper({
        defaultWidth: 1200,
        defaultHeight: 700
    });

    mainWindow = new BrowserWindow({
        'width': mainWindowState.width,
        'height': mainWindowState.height,
        // 'x': mainWindowState.x,
        // 'y': mainWindowState.y,
        'web-preferences': {
            'web-security': false
        }
    });

    mainWindowState.manage(mainWindow);
    mainWindow.loadURL(`file://${__dirname}/view/index.html`);
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
    mainWindow.maximize();
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
    app.quit();
});

app.on('activate', () => {
    if (mainWindow === null) {
        createWindow()
    }
});
