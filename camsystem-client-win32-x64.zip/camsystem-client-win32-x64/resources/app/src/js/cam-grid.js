(function () {
    'use strict';

    const cameraRepository = require('../js/camera-repository.js');
    const FFMPEGSource = require('../js/piped-process-source.js');
    const map = require('../js/map.js');

    let players = {};
    let grids = [1, 2, 3, 4];
    let selectedGrid = 1;
    let currentIndex = null;
    let mapMarkersGroup;

    module.exports.play = function () {
        document.querySelectorAll('.main-grid .player').forEach(player => {
            if (player.attributes['data-video']) {
                players[player.id] = new JSMpeg.Player('', {
                    canvas: player,
                    pauseWhenHidden: false,
                    audio: false,
                    source: FFMPEGSource,
                    params: player.attributes['data-params'].value,
                    input: player.attributes['data-url'].value,
                    width: player.width * 4,
                    height: player.height * 4
                });
            }
        });
    };

    module.exports.destroy = function () {
        if (!mapMarkersGroup) {
            mapMarkersGroup = L.layerGroup([]);
        } else {
            mapMarkersGroup.clearLayers();
        }
        document.querySelectorAll('.main-grid .player').forEach(player => {
            if (players[player.id]) {
                players[player.id].options.reconnectInterval = 0;
                players[player.id].stop();
                players[player.id].source.destroy();
            }
        });
        document.querySelectorAll('.pane-camera').forEach(pane => pane.remove());
    };

    function circularIndexArroundArray(index, array) {
        if (index < 0) {
            return array.length + index;
        } else if (index >= array.length) {
            return index - array.length;
        } else {
            return index;
        }
    }

    module.exports.setGridFormat = function (grid) {
        if (grid !== selectedGrid) {
            selectedGrid = grid;
            console.log('setgrid', selectedGrid)

            this.refresh();
        }
    };

    module.exports.refresh = function () {
        this._loadDataAndRender(currentIndex);
    };

    module.exports.getCurrentIndex = function () {
        return currentIndex;
    };

    module.exports.render = function (mainCameraIndex) {
        mainCameraIndex = mainCameraIndex || 0;
        if (currentIndex === mainCameraIndex) {
            return;
        }

        this._loadDataAndRender(mainCameraIndex);
    };

    function createMarker(camera, iconName) {
        let icon = L.icon({
            iconUrl: '../img/' + iconName + '.png',

            iconSize: [25, 41], // size of the icon
            iconAnchor: [12, 41], // point of the icon which will correspond to marker's location
        });
        return L.marker([camera.camera.latitude, camera.camera.longitude], {
            riseOnHover: true,
            title: camera.camera.name,
            icon: icon
        });
    }

    module.exports._loadDataAndRender = function (mainCameraIndex) {
        cameraRepository.getAll().then(cameras => {
            this.destroy();

            document
                .querySelectorAll('.camera-thumbnails .player-wrapper')
                .forEach(player => {
                    player.classList.remove('main-player');
                    player.classList.remove('second-player');
                });

            mainCameraIndex = circularIndexArroundArray(mainCameraIndex, cameras);
            currentIndex = mainCameraIndex;

            let paneSecondCamera = document.createElement('div');
            paneSecondCamera.classList.add('pane-sm');
            paneSecondCamera.classList.add('pane-second-camera');
            paneSecondCamera.classList.add('pane-camera');

            let camera1 = cameras[mainCameraIndex];
            let mainPanel = document.createElement('div');
            mainPanel.classList.add('pane');
            mainPanel.classList.add('pane-camera');
            mapMarkersGroup.addLayer(createMarker(camera1, 'selected-marker')).addTo(map);

            let canvas1 = cameraRepository.createCanvasElement('grid-', camera1, {
                width: '100%'
            });
            canvas1.classList.add('main-player');
            document.querySelectorAll('.camera-thumbnails .player-wrapper')[mainCameraIndex].classList.add('main-player');

            mainPanel.appendChild(canvas1);
            let mainGrid = document.querySelector('.main-grid');
            mainGrid.appendChild(mainPanel);

            if (selectedGrid >= 2) {
                if (selectedGrid >= 4) {
                    appendSecondaryCamera(paneSecondCamera, cameras, circularIndexArroundArray(mainCameraIndex - 2, cameras));
                }

                appendSecondaryCamera(paneSecondCamera, cameras, circularIndexArroundArray(mainCameraIndex - 1, cameras));

                if (selectedGrid >= 3) {
                    appendSecondaryCamera(paneSecondCamera, cameras, circularIndexArroundArray(mainCameraIndex + 1, cameras));
                }

                mainGrid.appendChild(paneSecondCamera);
            }

            this.play();
        });
    };

    function appendSecondaryCamera(paneSecondCamera, cameras, cameraIndex) {
        let camera = cameras[cameraIndex];
        let canvas = cameraRepository.createCanvasElement('grid-', camera, {
            width: '100%'
        });
        canvas.classList.add('second-player');
        paneSecondCamera.appendChild(canvas);
        mapMarkersGroup.addLayer(createMarker(camera, 'sub-selected-marker')).addTo(map);
        document.querySelectorAll('.camera-thumbnails .player-wrapper')[cameraIndex].classList.add('second-player');
    }
}());