(function () {
    'use strict';

    const ffmpeg = require('../js/ffmpeg.js');

    module.exports.play = function (options) {
        let context = options.canvas.getContext('2d');
        let process = ffmpeg.spawn({
            type: 'mjpeg',
            input: options.input,
            params: options.params,
            fps: options.fps,
            width: options.canvas.width,
            height: options.canvas.height,
            seek: options.seek
        });

        process.on('error', function (err) {
            console.debug(err);
        });

        process.on('close', function (code) {
            console.debug('ffmpeg exited with code ' + code);
        });

        process.stderr.on('data', function (data) {
            console.log('stderr: ' + data);
        });

        process.stdout.on('data', function (data) {
            let frame = new Buffer(data).toString('base64');
            let imageObject = new Image();
            imageObject.src = 'data:image/jpeg;base64,' + frame;
            imageObject.onload = function () {
                context.height = options.canvas.height;
                context.width = options.canvas.width;
                context.drawImage(imageObject, 0, 0, context.width, context.height);
            }
        });

        return {
            stop: function () {
                process.kill('SIGINT');
            }
        };
    };
}());