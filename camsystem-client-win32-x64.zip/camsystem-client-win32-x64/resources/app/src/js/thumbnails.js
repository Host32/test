(function () {
    'use strict';

    const cameraRepository = require('../js/camera-repository.js');
    const CanvasPlayer = require('../js/canvas-player.js');

    let players = {};

    module.exports.play = function () {
        document.querySelectorAll('.camera-thumbnails .player').forEach((player, i) => {
            if (player.attributes['data-video']) {
                players[player.id] = CanvasPlayer.play({
                    canvas: player,
                    fps: 1,
                    input: player.attributes['data-url'].value,
                    params: player.attributes['data-params'].value
                });
            }
        });
    };

    module.exports.destroy = function () {
        document.querySelectorAll('.camera-thumbnails .player').forEach(player => {
            if (players[player.id]) {
                players[player.id].stop();
            }
        });
        let thumbnailsArea = document.querySelector('.camera-thumbnails');
        thumbnailsArea.innerHTML = '';
    };

    module.exports.render = function () {
        cameraRepository.getAll().then(cameras => {
            let table = document.createElement('table');
            let tBody = document.createElement('tbody');
            let tr = document.createElement('tr');

            cameras.forEach(camera => {
                let td = document.createElement('td');

                let canvas = cameraRepository.createCanvasElement('thumbnail-', camera, {
                    height: '100px'
                });

                td.appendChild(canvas);
                tr.appendChild(td);
            });

            tBody.appendChild(tr);
            table.appendChild(tBody);

            this.destroy();

            let thumbnailsArea = document.querySelector('.camera-thumbnails');
            thumbnailsArea.appendChild(table);

            this.play();
        });
    };
}());