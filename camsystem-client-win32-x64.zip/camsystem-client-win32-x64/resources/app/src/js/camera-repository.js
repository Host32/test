(function () {
    'use strict';

    const fs = require('fs');
    const moment = require('moment');
    const properties = JSON.parse(fs.readFileSync('./properties.json', 'utf8'));
    const grid = require('../js/cam-grid.js');
    const map = require('../js/map.js');

    let cache = null;

    let mapMarkersGroup;

    setInterval(function () {
        cache = null;
    }, 10 * 60 * 1000);

    let playTime = moment();

    module.exports.setPlayTime = function (data) {
        playTime = data;
    };

    module.exports.resetPlayTime = function () {
        playTime = moment();
    };

    module.exports.getAll = function () {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: properties.apiServer + 'streamingApi/cameras',
                success: (data) => {
                    console.log(data);

                    if (!mapMarkersGroup) {
                        mapMarkersGroup = L.layerGroup([]);
                    } else {
                        mapMarkersGroup.clearLayers();
                    }

                    data.forEach((camera, index) => {
                        camera.index = index;

                        camera.marker =  L.marker([camera.camera.latitude, camera.camera.longitude], {
                            riseOnHover: true,
                            title: camera.camera.name
                        }).on('click', () => {
                            grid.render(camera.index);
                        });

                        mapMarkersGroup.addLayer(camera.marker);
                    });

                    mapMarkersGroup.addTo(map);
                    resolve(data);
                }
            })
        });
    };

    module.exports.createCanvasElement = function (idPrefix, camera, style) {
        let canvasPlayer = document.createElement('div');
        canvasPlayer.classList.add('player-wrapper');

        let canvasPlayerTitle = document.createElement('div');
        canvasPlayerTitle.classList.add('title');
        canvasPlayerTitle.innerHTML = camera.camera.name;

        canvasPlayer.appendChild(canvasPlayerTitle);

        let canvas = document.createElement('canvas');

        if (style) {
            for (let key in style) {
                if (style.hasOwnProperty(key)) {
                    canvas.style[key] = style[key];
                }
            }
        }

        canvas.classList.add('player');
        canvas.id = idPrefix + camera.camera.id;

        canvas.onclick = () => {
            grid.render(camera.index);
        };

        let canvasCamera = document.createAttribute('data-camera');
        canvasCamera.value = camera.camera.id;
        canvas.setAttributeNode(canvasCamera);

        let canvasVideo = document.createAttribute('data-video');
        canvasVideo.value = camera.streamUrl;
        canvas.setAttributeNode(canvasVideo);

        let canvasUrl = document.createAttribute('data-url');
        canvasUrl.value = camera.camera.address;
        canvas.setAttributeNode(canvasUrl);

        let canvasParams = document.createAttribute('data-params');
        canvasParams.value = camera.camera.params;
        canvas.setAttributeNode(canvasParams);

        canvasPlayer.appendChild(canvas);

        return canvasPlayer;
    };
}());