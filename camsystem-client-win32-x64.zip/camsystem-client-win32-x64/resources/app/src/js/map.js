(function () {
    let map = L.map('map').setView([-20.66987117, -43.78673250], 14);
    const fs = require('fs');
    const properties = JSON.parse(fs.readFileSync('./properties.json', 'utf8'));

    L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=' + properties.mapAccessToken, {
        attribution: '',
        maxZoom: 18,
        id: 'mapbox.streets'
    }).addTo(map);

    module.exports = map;
}());