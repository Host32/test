'use strict';

console.debug = function () {
};

const thumbnails = require('../js/thumbnails.js');
const grid = require('../js/cam-grid.js');
const resizable = require('../js/resizable.js');
const map = require('../js/map.js');

thumbnails.render();
grid.render();

resizable.setResizable(document.querySelector('.pane-maps'), {
    disableResizeHeight: true,
    position: 'right',
    onResize: () => {
        map.invalidateSize();
    }
});

document.querySelectorAll('.btn-select-grid').forEach(button => {
    button.onclick = () => {
        grid.setGridFormat(parseInt(button.attributes['data-grid'].value, 10));
    };
});

let patrolInterval = null;
document.querySelector('.btn-start-patrol').onclick = function () {
    if (patrolInterval) {
        clearInterval(patrolInterval);
    }

    patrolInterval = setInterval(function () {
        grid.render(grid.getCurrentIndex() + 1);
    }, 15000);

    document.querySelector('.btn-start-patrol').classList.add('hidden');
    document.querySelector('.btn-stop-patrol').classList.remove('hidden');
};
document.querySelector('.btn-stop-patrol').onclick = function () {
    if (patrolInterval) {
        clearInterval(patrolInterval);
    }
    document.querySelector('.btn-stop-patrol').classList.add('hidden');
    document.querySelector('.btn-start-patrol').classList.remove('hidden');
};