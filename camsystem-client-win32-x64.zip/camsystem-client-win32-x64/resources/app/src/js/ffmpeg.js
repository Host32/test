(function () {
    'use strict';

    const process = require('child_process');
    const fs = require('fs');
    const properties = JSON.parse(fs.readFileSync('./properties.json', 'utf8'));

    let pool = {};

    exports.spawn = function (options) {
        if (options.type === 'mpegts') {
            return this.spawnMpegts(options);
        } else {
            return this.spawnMjpeg(options);
        }
    };

    exports.spawnMpegts = function (options) {
        if (!pool[options.input]) {
            let params = addParams([
                '-r', options.fps || 30,
                '-i', options.input,
                '-f', 'mpegts',
                '-codec:v', 'mpeg1video',
                '-s', options.width + 'x' + options.height,
                '-r', '30',
                '-nostats',
                'pipe:1'
            ], options.params);

            console.log('starting ffmpeg', params);

            pool[options.input] = process.spawn(properties.ffmpegPath, params);

            pool[options.input].on('close', function () {
                delete pool[options.input];
            });

            pool[options.input].stderr.on('data', function (data) {
                console.debug('stderr: ' + data);
            });

            pool[options.input].on('error', function (err) {
                console.debug(err);
            });
        }
        return pool[options.input];
    };

    exports.spawnMjpeg = function (options) {
        let params = addParams([
            '-i', options.input,
            '-f', 'mjpeg',
            '-s', options.width + 'x' + options.height,
            '-r', options.fps,
            '-nostats',
            'pipe:1'
        ], options.params);

        console.log('starting ffmpeg', params);

        return process.spawn(properties.ffmpegPath, params);
    };

    function addParams(defaultParams, additionalParams) {
        additionalParams = additionalParams ? additionalParams.split(' ').reverse() : [];

        additionalParams.forEach((param) => {
            defaultParams.unshift(param);
        });

        return defaultParams;
    }
}());
