(function () {
    'use strict';

    module.exports.setResizable = function (element, options) {
        options = options || {};

        element.classList.add('resizable');
        let resizer = document.createElement('div');
        resizer.classList.add('resizer');

        if (!options.disableResizeWidth) {
            resizer.classList.add('resizer-width');
        }
        if (!options.disableResizeHeight) {
            resizer.classList.add('resizer-height');
        }

        if (options.position.indexOf('top')!== -1) {
            resizer.classList.add('resizer-top');
        }

        if (options.position.indexOf('left')!== -1) {
            resizer.classList.add('resizer-left');
        }

        if (options.position.indexOf('right')!== -1) {
            resizer.classList.add('resizer-right');
        }

        if (options.position.indexOf('bottom')!== -1) {
            resizer.classList.add('resizer-bottom');
        }

        element.appendChild(resizer);
        resizer.addEventListener('mousedown', initDrag, false);

        let startX, startY, startWidth, startHeight;

        function initDrag(e) {
            startX = e.clientX;
            startY = e.clientY;
            startWidth = parseInt(document.defaultView.getComputedStyle(element).width, 10);
            startHeight = parseInt(document.defaultView.getComputedStyle(element).height, 10);
            document.documentElement.addEventListener('mousemove', doDrag, false);
            document.documentElement.addEventListener('mouseup', stopDrag, false);
        }

        function doDrag(e) {
            if (!options.disableResizeWidth) {
                element.style.width = (startWidth + e.clientX - startX) + 'px';
            }
            if (!options.disableResizeHeight) {
                element.style.height = (startHeight + e.clientY - startY) + 'px';
            }
        }

        function stopDrag(e) {
            document.documentElement.removeEventListener('mousemove', doDrag, false);
            document.documentElement.removeEventListener('mouseup', stopDrag, false);
            if(options.onResize){
                options.onResize();
            }
        }
    };
}());