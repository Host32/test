(function () {
    'use strict';

    const ffmpeg = require('../js/ffmpeg.js');

    function FFMPEGSource(url, options) {
        this.url = url;
        this.options = options;
        this.process = null;
        this.streaming = true;

        this.destination = null;

        this.reconnectInterval = options.reconnectInterval !== undefined
            ? options.reconnectInterval
            : 5;
        this.shouldAttemptReconnect = !!this.reconnectInterval;

        this.completed = false;
        this.established = false;
        this.progress = 0;

        this.reconnectTimeoutId = 0;
    }

    FFMPEGSource.prototype.connect = function (destination) {
        this.destination = destination;
    };

    FFMPEGSource.prototype.destroy = function () {
        clearTimeout(this.reconnectTimeoutId);
        this.shouldAttemptReconnect = false;
        this.process.removeListener('close', this.onCloseProcess);
        this.process.stdout.removeListener('data', this.onDataInProcess);
    };

    FFMPEGSource.prototype.onCloseProcess = function (code) {
        console.debug('close: ' + code);
        if (this.shouldAttemptReconnect) {
            clearTimeout(this.reconnectTimeoutId);
            this.reconnectTimeoutId = setTimeout(function () {
                this.start();
            }.bind(this), this.reconnectInterval * 1000);
        }
    };

    FFMPEGSource.prototype.onDataInProcess = function (data) {
        this.progress = 1;
        this.established = true;
        if (this.destination) {
            this.destination.write(data);
        }
    };

    FFMPEGSource.prototype.start = function () {
        this.shouldAttemptReconnect = !!this.reconnectInterval;
        this.progress = 0;
        this.established = false;

        this.process = ffmpeg.spawn({
            type: 'mpegts',
            params: this.options.params,
            input: this.options.input, //this.options.cameraId + "\\videos\\" + this.options.videoFileName,
            fps: this.options.fps,
            width: this.options.width || this.options.canvas.width,
            height: this.options.height || this.options.canvas.height
        });

        this.process.on('close', this.onCloseProcess.bind(this));

        this.process.stdout.on('data', this.onDataInProcess.bind(this));
    };

    FFMPEGSource.prototype.resume = function (secondsHeadroom) {
        // Nothing to do here
    };

    module.exports = FFMPEGSource;
}());