(function () {
    'use strict';
    const cameraRepository = require('../js/camera-repository.js');
    const _ = require('lodash');
    const thumbnails = require('../js/thumbnails.js');
    const grid = require('../js/cam-grid.js');
    const moment = require('moment');

    module.exports.render = function () {
        cameraRepository.getAll().then(function (cameras) {
            let groups = cameras.map(camera => {
                return {
                    id: camera.id,
                    content: 'Camera ' + camera.id
                };
            });

            let items = _.flatten(cameras.map(camera => {
                return camera.videos.map(video => {
                    return {
                        start: video.startDate,
                        end: new Date(video.startDate.getTime() + (video.duration * 1000)),
                        style: 'height: 20px',
                        group: camera.id
                    };
                });
            }));

            let timeLine = new vis.Timeline(document.querySelector('.time-line'), items, groups, {
                height: '150px',
                stack: false,
                selectable: false
            });
            setTimeout(() => {
                let now = new Date();
                timeLine.moveTo(now);
                timeLine.setWindow(new Date(now.getTime() - 10 * 60 * 1000), new Date(now.getTime() + 10 * 60 * 1000));
            }, 1000);

            timeLine.on('doubleClick', ev => {
                console.log(ev);
                timeLine.setCurrentTime(ev.time);
                cameraRepository.setPlayTime(moment(ev.time));
                grid.render();
                thumbnails.render();
            });
        });
    };
}());